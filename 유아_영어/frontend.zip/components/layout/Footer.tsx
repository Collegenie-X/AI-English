'use client'

import Link from 'next/link'
import { GameMascot } from '@/components/mascot/GameMascot'

const NAV_COLUMNS = [
  {
    heading: '학습',
    color: '#FF86C8',
    links: [
      { href: '/ko',         label: '한글 배우기',  note: '유아 한글 단어' },
      { href: '/en',         label: '영어 배우기',  note: '알파벳 · 파닉스' },
      { href: '/en/phonics', label: '회화 도서관',  note: '회화패턴 · 청크' },
    ],
  },
  {
    heading: '게임 모드',
    color: '#1CB0F6',
    links: [
      { href: '/ko', label: '학습 모드',  note: '그림 카드 학습' },
      { href: '/ko', label: '퀴즈 모드',  note: '객관식 · 주관식' },
      { href: '/ko', label: '낱말 퍼즐',  note: '단어 찾기 게임' },
    ],
  },
  {
    heading: '자료실',
    color: '#58CC02',
    links: [
      { href: '/resources', label: '영어 교육 자료',   note: 'PDF · 영상 자료' },
      { href: '/resources', label: '영어 독해',        note: '읽기 · 이해력' },
      { href: '/resources', label: '한글 독해',        note: '어휘 · 문장 이해' },
    ],
  },
  {
    heading: '내 기록',
    color: '#FFD900',
    links: [
      { href: '/my', label: '학습 기록',  note: '일별 스트릭 확인' },
      { href: '/my', label: 'XP & 레벨', note: '경험치 현황' },
      { href: '/my', label: '성취 뱃지',  note: '획득한 배지 보기' },
    ],
  },
]

export function Footer() {
  return (
    <footer
      aria-label="사이트 푸터"
      style={{ backgroundColor: '#1a1d27', color: '#c8ccd8' }}
    >
      {/* ── Top band: columns ── */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 sm:py-14">
        {/* Mobile: stack brand + 2-col grid for links */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '32px',
          }}
          className="sm:hidden"
        >
          {/* Brand — full width on mobile */}
          <div style={{ gridColumn: '1 / -1' }}>
            <BrandBlock />
          </div>
          {/* Link columns 2-up on mobile */}
          {NAV_COLUMNS.map((col) => (
            <NavColumn key={col.heading} col={col} />
          ))}
        </div>

        {/* Desktop: 5-column grid (brand + 4 nav cols) */}
        <div
          className="hidden sm:grid"
          style={{
            gridTemplateColumns: '1.1fr 1fr 1fr 1fr 1fr',
            gap: '40px',
            alignItems: 'start',
          }}
        >
          <BrandBlock />
          {NAV_COLUMNS.map((col) => (
            <NavColumn key={col.heading} col={col} />
          ))}
        </div>
      </div>

      {/* ── Divider ── */}
      <div
        style={{
          height: 1,
          background: 'linear-gradient(90deg, transparent, #2e3347 20%, #2e3347 80%, transparent)',
        }}
      />

      {/* ── Bottom bar ── */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-5">
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '12px',
            flexWrap: 'wrap',
          }}
        >
          <p className="text-xs font-semibold" style={{ color: '#5c6278' }}>
            &copy; {new Date().getFullYear()} LingoBaby. All rights reserved.
          </p>

          <div style={{ display: 'flex', gap: '20px', alignItems: 'center', flexWrap: 'wrap' }}>
            {[
              { href: '/ko',        label: '한글',  color: '#FF86C8' },
              { href: '/en',        label: '영어',  color: '#1CB0F6' },
              { href: '/en/phonics',label: '회화',  color: '#58CC02' },
              { href: '/resources', label: '자료실', color: '#00C2A0' },
              { href: '/my',        label: '기록',  color: '#FFD900' },
            ].map(item => (
              <Link
                key={item.href}
                href={item.href}
                className="text-xs font-black"
                style={{ color: item.color, opacity: 0.75, textDecoration: 'none' }}
                onMouseEnter={e => (e.currentTarget.style.opacity = '1')}
                onMouseLeave={e => (e.currentTarget.style.opacity = '0.75')}
              >
                {item.label}
              </Link>
            ))}
          </div>

          <p className="text-xs font-semibold hidden sm:block" style={{ color: '#5c6278' }}>
            Made with care for young learners
          </p>
        </div>
      </div>
    </footer>
  )
}

// ── Sub-components ────────────────────────────────────────────────────────────

function BrandBlock() {
  return (
    <div>
      <Link href="/" className="inline-flex items-center gap-2 mb-4" aria-label="LingoBaby 홈" style={{ textDecoration: 'none' }}>
        <GameMascot mood="idle" size={38} />
        <span className="font-black text-lg" style={{ color: 'white', letterSpacing: '-0.5px' }}>
          Lingo<span style={{ color: '#58CC02' }}>Baby</span>
        </span>
      </Link>
      <p className="text-sm font-semibold leading-relaxed" style={{ color: '#8b91a8', maxWidth: 200 }}>
        게임처럼 재미있게 배우는<br />한글 &amp; 영어 학습 플랫폼
      </p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '16px' }}>
        {[
          { tag: '한글', color: '#FF86C8' },
          { tag: '영어', color: '#1CB0F6' },
          { tag: '자료실', color: '#58CC02' },
          { tag: '퍼즐', color: '#FFD900' },
        ].map(({ tag, color }) => (
          <span
            key={tag}
            className="text-xs font-black px-3 py-1 rounded-full"
            style={{
              background: `${color}22`,
              color,
              border: `1px solid ${color}44`,
            }}
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  )
}

interface ColDef { heading: string; color: string; links: { href: string; label: string; note: string }[] }

function NavColumn({ col }: { col: ColDef }) {
  return (
    <div>
      <h3
        className="text-xs font-black uppercase tracking-widest mb-4"
        style={{ color: col.color }}
      >
        {col.heading}
      </h3>
      <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {col.links.map(link => (
          <li key={link.label}>
            <Link href={link.href} style={{ display: 'block', textDecoration: 'none' }}>
              <span
                className="text-sm font-bold block transition-colors duration-150"
                style={{ color: '#e2e5ef' }}
                onMouseEnter={e => (e.currentTarget.style.color = col.color)}
                onMouseLeave={e => (e.currentTarget.style.color = '#e2e5ef')}
              >
                {link.label}
              </span>
              <span className="text-xs font-semibold" style={{ color: '#5c6278' }}>
                {link.note}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
