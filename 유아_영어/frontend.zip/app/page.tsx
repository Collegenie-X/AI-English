import Link from 'next/link'
import { GameMascot } from '@/components/mascot/GameMascot'

const SUBJECTS = [
  {
    href: '/ko',
    label: '한글',
    title: '한글 배우기',
    desc: '귀엽고 재미있는 그림 카드로 한글 단어를 배워요',
    color: '#FF86C8',
    dark: '#E05EA8',
    light: '#FFF0FA',
    badge: '4단계',
    words: '100+ 단어',
    icon: (
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" aria-hidden>
        <rect x="4" y="3" width="7" height="18" rx="1.5" fill="#FF86C8" opacity=".9" />
        <rect x="13" y="3" width="7" height="18" rx="1.5" fill="#FF86C8" opacity=".6" />
        <rect x="2" y="3" width="2" height="18" rx="1" fill="#FF86C8" opacity=".4" />
      </svg>
    ),
  },
  {
    href: '/en',
    label: '영어',
    title: '영어 배우기',
    desc: '알파벳부터 회화패턴까지 단계별 영어 학습',
    color: '#1CB0F6',
    dark: '#0A98DA',
    light: '#E8F8FF',
    badge: '4스테이지',
    words: '200+ 단어',
    icon: (
      <svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor" aria-hidden style={{ color: '#1CB0F6' }}>
        <polygon points="12,2 14.9,8.5 22,9.3 16.9,14.2 18.4,21 12,17.6 5.6,21 7.1,14.2 2,9.3 9.1,8.5" />
      </svg>
    ),
  },
  {
    href: '/en/phonics',
    label: '회화',
    title: '회화 도서관',
    desc: '실생활 회화패턴과 청크 문장을 통으로 배워요',
    color: '#58CC02',
    dark: '#46A302',
    light: '#EDFFD0',
    badge: '2스테이지',
    words: '50+ 패턴',
    icon: (
      <svg width="36" height="36" viewBox="0 0 24 24" fill="#58CC02" aria-hidden>
        <path d="M4 4h16a2 2 0 012 2v9a2 2 0 01-2 2H8l-4 3V6a2 2 0 012-2z" />
      </svg>
    ),
  },
  {
    href: '/my',
    label: '기록',
    title: '내 학습 기록',
    desc: '스트릭, XP, 성취 배지로 꾸준한 학습을 응원해요',
    color: '#FFD900',
    dark: '#DEB800',
    light: '#FFFBE0',
    badge: '스트릭',
    words: 'XP & 배지',
    icon: (
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M8 2h8v8a4 4 0 01-8 0V2z" fill="#FFD900" />
        <path d="M6 2H3v4a3 3 0 003 3M18 2h3v4a3 3 0 01-3 3M12 14v4M9 21h6"
          stroke="#FFD900" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
  },
]

const FEATURES = [
  {
    icon: '🎴',
    title: '그림 카드 학습',
    desc: '귀여운 이모지 카드를 클릭하면 원어민 발음이 나와요',
    color: '#FF86C8',
  },
  {
    icon: '❓',
    title: '퀴즈 모드',
    desc: '객관식 & 주관식 퀴즈로 배운 단어를 확인해요',
    color: '#1CB0F6',
  },
  {
    icon: '🧩',
    title: '낱말 퍼즐',
    desc: '격자에서 단어를 찾는 재미있는 퍼즐 게임',
    color: '#58CC02',
  },
  {
    icon: '🔥',
    title: '학습 스트릭',
    desc: '매일 꾸준히 학습하면 스트릭이 쌓여요',
    color: '#FFD900',
  },
]

export default function HomePage() {
  return (
    <div style={{ backgroundColor: '#f7f8fa', minHeight: '100vh' }}>

      {/* ── Hero section ── */}
      <section
        style={{
          position: 'relative',
          overflow: 'hidden',
          background: 'linear-gradient(135deg, #e8f8ff 0%, #fff0fa 50%, #edffd0 100%)',
          borderBottom: '2px solid #e8eaf0',
        }}
      >
        {/* Dot texture */}
        <div
          style={{
            position: 'absolute', inset: 0, opacity: 0.4,
            backgroundImage: 'radial-gradient(circle, #1CB0F620 1px, transparent 1px)',
            backgroundSize: '28px 28px',
            pointerEvents: 'none',
          }}
        />

        <div
          className="max-w-5xl mx-auto px-4 sm:px-6"
          style={{
            position: 'relative',
            paddingTop: '64px',
            paddingBottom: '64px',
            display: 'flex',
            alignItems: 'center',
            gap: '40px',
          }}
        >
          {/* Text */}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div
              style={{
                display: 'inline-flex', alignItems: 'center', gap: '8px',
                padding: '5px 14px', borderRadius: '20px',
                background: '#58CC0218', border: '1.5px solid #58CC0244',
                marginBottom: '18px',
              }}
            >
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#58CC02', display: 'inline-block' }} />
              <span style={{ fontSize: '0.78rem', fontWeight: 800, color: '#46A302' }}>유아 한글 &amp; 영어 학습</span>
            </div>

            <h1
              style={{
                fontSize: 'clamp(1.8rem, 5vw, 2.8rem)',
                fontWeight: 900,
                color: '#1a1d27',
                lineHeight: 1.15,
                marginBottom: '16px',
                letterSpacing: '-0.5px',
              }}
              className="text-balance"
            >
              게임처럼 재미있게<br />
              <span style={{ color: '#1CB0F6' }}>한글</span>과{' '}
              <span style={{ color: '#58CC02' }}>영어</span>를 배워요
            </h1>

            <p
              style={{
                fontSize: '1rem',
                color: '#555',
                fontWeight: 600,
                lineHeight: 1.6,
                marginBottom: '28px',
                maxWidth: 440,
              }}
              className="text-pretty"
            >
              그림 카드, 퀴즈, 낱말 퍼즐로 아이들이 즐겁게 단어를 익힐 수 있어요.
              원어민 발음으로 듣고 따라해 보세요.
            </p>

            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <Link
                href="/ko"
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: '8px',
                  padding: '12px 28px', borderRadius: '16px',
                  background: '#FF86C8', color: 'white',
                  fontSize: '0.95rem', fontWeight: 900,
                  textDecoration: 'none',
                  boxShadow: '0 4px 0 #E05EA8',
                  transition: 'transform 0.1s, box-shadow 0.1s',
                }}
                onMouseOver={e => {
                  ;(e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)'
                  ;(e.currentTarget as HTMLElement).style.boxShadow = '0 6px 0 #E05EA8'
                }}
                onMouseOut={e => {
                  ;(e.currentTarget as HTMLElement).style.transform = ''
                  ;(e.currentTarget as HTMLElement).style.boxShadow = '0 4px 0 #E05EA8'
                }}
              >
                한글 배우기 시작
              </Link>
              <Link
                href="/en"
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: '8px',
                  padding: '12px 28px', borderRadius: '16px',
                  background: '#1CB0F6', color: 'white',
                  fontSize: '0.95rem', fontWeight: 900,
                  textDecoration: 'none',
                  boxShadow: '0 4px 0 #0A98DA',
                  transition: 'transform 0.1s, box-shadow 0.1s',
                }}
                onMouseOver={e => {
                  ;(e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)'
                  ;(e.currentTarget as HTMLElement).style.boxShadow = '0 6px 0 #0A98DA'
                }}
                onMouseOut={e => {
                  ;(e.currentTarget as HTMLElement).style.transform = ''
                  ;(e.currentTarget as HTMLElement).style.boxShadow = '0 4px 0 #0A98DA'
                }}
              >
                영어 배우기 시작
              </Link>
            </div>
          </div>

          {/* Mascot */}
          <div
            style={{
              flexShrink: 0,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '12px',
            }}
            className="hidden sm:flex"
          >
            <GameMascot mood="speaking" size={120} />
            <div
              style={{
                background: 'white',
                borderRadius: '16px',
                padding: '8px 16px',
                fontSize: '0.8rem',
                fontWeight: 800,
                color: '#333',
                boxShadow: '0 4px 16px rgba(0,0,0,0.1)',
                border: '2px solid #e8eaf0',
                whiteSpace: 'nowrap',
              }}
            >
              안녕하세요! 같이 배워요 :)
            </div>
          </div>
        </div>
      </section>

      {/* ── Subject cards ── */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6" style={{ paddingTop: '48px', paddingBottom: '16px' }}>
        <h2
          style={{
            fontSize: '1.15rem', fontWeight: 900, color: '#1a1d27',
            marginBottom: '20px', textAlign: 'center',
          }}
        >
          무엇을 배울까요?
        </h2>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
            gap: '16px',
          }}
        >
          {SUBJECTS.map(s => (
            <Link
              key={s.href}
              href={s.href}
              style={{ textDecoration: 'none' }}
            >
              <div
                style={{
                  background: 'white',
                  borderRadius: '20px',
                  border: `2px solid ${s.color}33`,
                  boxShadow: `0 2px 12px rgba(0,0,0,0.07), 0 4px 0 ${s.color}33`,
                  overflow: 'hidden',
                  transition: 'transform 0.15s, box-shadow 0.15s',
                  cursor: 'pointer',
                }}
                onMouseOver={e => {
                  ;(e.currentTarget as HTMLElement).style.transform = 'translateY(-5px)'
                  ;(e.currentTarget as HTMLElement).style.boxShadow = `0 12px 28px rgba(0,0,0,0.13), 0 6px 0 ${s.color}44`
                }}
                onMouseOut={e => {
                  ;(e.currentTarget as HTMLElement).style.transform = ''
                  ;(e.currentTarget as HTMLElement).style.boxShadow = `0 2px 12px rgba(0,0,0,0.07), 0 4px 0 ${s.color}33`
                }}
              >
                {/* Color top */}
                <div
                  style={{
                    background: s.light,
                    padding: '24px 20px 20px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderBottom: `2px solid ${s.color}22`,
                    minHeight: '90px',
                  }}
                >
                  {s.icon}
                </div>

                {/* Body */}
                <div style={{ padding: '14px 16px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                    <span
                      style={{
                        fontSize: '1.05rem', fontWeight: 900, color: '#1a1d27',
                      }}
                    >
                      {s.title}
                    </span>
                    <span
                      style={{
                        fontSize: '0.68rem', fontWeight: 800, padding: '2px 8px',
                        borderRadius: '8px', background: `${s.color}18`, color: s.color,
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {s.badge}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.78rem', color: '#777', fontWeight: 600, lineHeight: 1.5, marginBottom: '10px' }}>
                    {s.desc}
                  </p>
                  <span
                    style={{
                      fontSize: '0.72rem', fontWeight: 800, color: s.color,
                    }}
                  >
                    {s.words} &rarr;
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* ── Features ── */}
      <section
        className="max-w-5xl mx-auto px-4 sm:px-6"
        style={{ paddingTop: '48px', paddingBottom: '64px' }}
      >
        <h2
          style={{
            fontSize: '1.15rem', fontWeight: 900, color: '#1a1d27',
            marginBottom: '20px', textAlign: 'center',
          }}
        >
          이런 방법으로 배워요
        </h2>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
            gap: '14px',
          }}
        >
          {FEATURES.map(f => (
            <div
              key={f.title}
              style={{
                background: 'white',
                borderRadius: '16px',
                border: `2px solid ${f.color}22`,
                padding: '20px 18px',
                boxShadow: '0 2px 10px rgba(0,0,0,0.06)',
              }}
            >
              <div
                style={{
                  width: 44, height: 44, borderRadius: '14px',
                  background: `${f.color}18`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '1.4rem', marginBottom: '12px',
                }}
              >
                {f.icon}
              </div>
              <h3 style={{ fontSize: '0.88rem', fontWeight: 900, color: '#1a1d27', marginBottom: '6px' }}>
                {f.title}
              </h3>
              <p style={{ fontSize: '0.76rem', color: '#888', fontWeight: 600, lineHeight: 1.55 }}>
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
